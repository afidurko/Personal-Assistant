# Promoted from Personal-Assistant

Source: `integrations/illa-desktop`  
Packager pin: electron-builder@26.16.1  
Base branch: `beta`  
Feature branch: `cursor/desktop-electron-26-16-1`

Do not bump to electron-builder v27 / fork master without an explicit migrate.
